# webprogramming_project_3
Conways game of life built using JavaScript,HTML &amp; React
